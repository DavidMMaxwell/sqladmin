/***************************************************************
  Name: ADR Transaction Handling
  Author: David M Maxwell (david.maxwell@microsoft.com)
  Last Updated: May 45 2020
  Notes: Delete / Rollback transaction examples with ADR. 

  Based on code by Bob Ward. Download full workshop from: 
  https://github.com/microsoft/sqlworkshops-sql2019workshop
  
***************************************************************/
SET NOCOUNT ON;
USE DemoADR
GO 

/* Create and populate a data table to perform transactions on. */
DROP TABLE IF EXISTS dbo.DataTable; 
GO 

CREATE TABLE dbo.DataTable(
    ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED, 
    TextCol CHAR(8000) NOT NULL
)
GO 

/* This takes somewhere around a minute or so.. */
DECLARE @counter INT
SET @counter = 0 

WHILE @counter < 450
BEGIN 
    INSERT INTO dbo.DataTable (TextCol)
    SELECT 'Sample Text.'
    SET @counter = @counter + 1
END 
GO

INSERT INTO dbo.DataTable(TextCol)
SELECT a.TextCol
FROM dbo.DataTable a
CROSS JOIN dbo.DataTable b
GO 

/* RowCounts should be 202,950 */
SELECT COUNT(*) AS RowCounts 
FROM dbo.DataTable; 
GO 

/* Switch to [master] and ensure that ADR is OFF. */
USE [master]; 
GO 
ALTER DATABASE DemoADR
SET ACCELERATED_DATABASE_RECOVERY = OFF; 
GO

/* Switch back to DemoADR and examine log space used. Should be low. */
USE DemoADR;
GO

/* Clean up the transaction log. */
CHECKPOINT; 
GO 

SELECT [Log MB Used] = CAST(used_log_space_in_bytes / 1048576.0 AS decimal(15,2)), 
       [Log % Used] = used_log_space_in_percent
FROM sys.dm_db_log_space_usage;
GO 

/* Get the max LSN from the transaction log. We'll need this in a minute. */
/* LSN: 00000051:01833040:0197 */
SELECT [dbo].[GetIntegerStringFromHex](MAX([Current LSN]),1) AS maxlsn
FROM fn_dblog(null,null)

/* Now delete all rows from the table, using an explicit transaction. (~ 30 sec)*/
BEGIN TRAN 
DELETE FROM dbo.DataTable
GO 

/* Examine log space used. */
SELECT [Log MB Used] = CAST(used_log_space_in_bytes / 1048576.0 AS decimal(15,2)), 
       [Log % Used] = used_log_space_in_percent
FROM sys.dm_db_log_space_usage;
GO 


/* Show the current transactions in the log */
SELECT COUNT(*) As OperationCount, Operation, Context  
FROM sys.fn_dblog('00000051:01833040:0197',null)
GROUP BY Operation, Context
ORDER BY OperationCount DESC;
GO 

/* Show the open transaction */
DBCC OPENTRAN;
GO

SELECT @@TRANCOUNT;
GO

/* Show the current rowcount of the table */
SELECT COUNT(*) AS RowCounts FROM dbo.DataTable; 
GO 

/* Now roll back the transaction and see how long it takes. */
ROLLBACK TRAN;
GO 

SELECT [Log MB Used] = CAST(used_log_space_in_bytes / 1048576.0 AS decimal(15,2)), 
       [Log % Used] = used_log_space_in_percent
FROM sys.dm_db_log_space_usage;
GO 



/* Switch back to [master] and enable ADR. */
USE [master]; 
GO

ALTER DATABASE [DemoADR] 
SET ACCELERATED_DATABASE_RECOVERY = ON (
    PERSISTENT_VERSION_STORE_FILEGROUP = DemoADR_FG_PVS
);
GO 

/* Clear up the log usage. */
USE DemoADR;
GO
CHECKPOINT 
GO

/* Get the max LSN from the transaction log. (00000054:02092144:0001) */
SELECT [dbo].[GetIntegerStringFromHex](MAX([Current LSN]),1) AS maxlsn
FROM fn_dblog(null,null)
GO 

/* Now repeat the delete operation, again in an explicit transaction. */
BEGIN TRAN; 
DELETE FROM dbo.DataTable; 
GO 

/* Show the current transactions in the log */
SELECT COUNT(*) As OperationCount, Operation, Context  
FROM sys.fn_dblog('00000056:00263048:0001',null)
GROUP BY Operation, Context
ORDER BY OperationCount DESC;
GO 

/* Show the open transaction...? */
DBCC OPENTRAN;
GO

SELECT @@TRANCOUNT
GO 

/* Show the current rowcount of the table. */
SELECT COUNT(*) AS RowCounts FROM dbo.DataTable; 
GO 

/* Current log space used. More or less than before? */
SELECT [Log MB Used] = CAST(used_log_space_in_bytes / 1048576.0 AS decimal(15,2)), 
       [Log % Used] = used_log_space_in_percent
FROM sys.dm_db_log_space_usage;
GO 

/* What's in the PVS at this moment? */
SELECT 
    DBName = db.name, 
    ADR_State = CASE db.is_accelerated_database_recovery_on WHEN 1 THEN 'Enabled' ELSE 'Disabled' END,
    FGName = fg.name, 
    PVS_Size_KB = pvss.persistent_version_store_size_kb, 
    Online_Index_VS_KB = pvss.online_index_version_store_size_kb,
    Secondary_Low_Watermark = pvss.secondary_low_water_mark
FROM sys.dm_tran_persistent_version_store_stats pvss 
INNER JOIN master.sys.databases db 
    on pvss.database_id = db.database_id 
INNER JOIN. sys.filegroups fg 
    ON fg.data_space_id = pvss.pvs_filegroup_id
WHERE pvss.database_id = db_id();
GO 

/* Checkpoint and examine the log space now. */
CHECKPOINT; 
GO 

SELECT [Log MB Used] = CAST(used_log_space_in_bytes / 1048576.0 AS decimal(15,2)), 
       [Log % Used] = used_log_space_in_percent
FROM sys.dm_db_log_space_usage;
GO 

/* Now see how long the rollback takes. */
ROLLBACK TRAN
GO

/* Verify the current row count. */
SELECT COUNT(*) AS RowCounts FROM dbo.DataTable; 
GO 