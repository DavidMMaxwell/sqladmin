/***************************************************************
  Name: Recovery with ADR
  Author: David M Maxwell (david.maxwell@microsoft.com)
  Last Updated: Apr 22 2020
  Notes: 
  
***************************************************************/
SET NOCOUNT ON;
USE master;
GO

/* Ensure ADR is OFF */
ALTER DATABASE DemoADR 
SET ACCELERATED_DATABASE_RECOVERY = OFF;
GO

SELECT name, is_accelerated_database_recovery_on 
FROM sys.databases
WHERE name = N'DemoADR'; 
GO 

/* Recreate the demo table, but much larger this time. */
USE DemoADR;
GO 

DROP TABLE IF EXISTS dbo.DataTable;
GO

CREATE TABLE dbo.DataTable(
    ID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED, 
    TextCol CHAR(8000) NOT NULL
)
GO 

DECLARE @counter INT
SET @counter = 0 

WHILE @counter < 450   
BEGIN 
    INSERT INTO dbo.DataTable (TextCol)
    SELECT 'Sample Text.'
    SET @counter = @counter + 1
END 
GO 

INSERT INTO dbo.DataTable(TextCol)
SELECT a.TextCol
FROM dbo.DataTable a
CROSS JOIN dbo.DataTable b

SELECT COUNT(*) AS RecordsInTable
FROM dbo.DataTable;
GO 

/* Copy this code to another window and run as soon as the delete starts. */
/* 
USE DemoADR;
GO
CHECKPOINT;
GO
SHUTDOWN WITH NOWAIT;
GO
*/

/* Start the UPDATE. */
USE DemoADR;
GO
BEGIN TRAN 
UPDATE dbo.DataTable
SET TextCol = 'Updated Text'
GO 


/* Examine the startup messages in the log for DemoADR. */
EXEC xp_readerrorlog 0,1,N'DemoADR';
GO


/* Now switch to [master] and turn ADR ON. */
USE [master]; 
GO

ALTER DATABASE [DemoADR] 
SET ACCELERATED_DATABASE_RECOVERY = ON (
    PERSISTENT_VERSION_STORE_FILEGROUP = DemoADR_FG_PVS
);
GO 

/* Copy this code to another window and run as soon as the delete starts. */
/* 
USE DemoADR;
GO
CHECKPOINT;
GO
SHUTDOWN WITH NOWAIT;
GO
*/

/* Start the delete again, and kill it from the second window. */
USE DemoADR;
GO
BEGIN TRAN 
UPDATE dbo.DataTable
SET TextCol = 'Updated Text'
GO 

/* Now examine the ADR message after the server starts. */
EXEC xp_readerrorlog 0,1,N'DemoADR';
GO

