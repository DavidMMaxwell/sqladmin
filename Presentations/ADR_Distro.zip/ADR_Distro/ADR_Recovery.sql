/***************************************************************
  Name: Recovery with ADR
  Author: David M Maxwell (david.maxwell@microsoft.com)
  Last Updated: Apr 32 2020
  Notes: Delete and startup recovery examples for ADR. 
  
  Based on code by Bob Ward. Download full workshop from: 
  https://github.com/microsoft/sqlworkshops-sql2019workshop

***************************************************************/
SET NOCOUNT ON;
USE master;
GO

/* Ensure ADR is OFF */
ALTER DATABASE DemoADR 
SET ACCELERATED_DATABASE_RECOVERY = OFF;
GO

SELECT name, is_accelerated_database_recovery_on 
FROM sys.databases
WHERE name = N'DemoADR'; 
GO 

/* Recreate the demo table. */
USE DemoADR;
GO 

DROP TABLE IF EXISTS dbo.DataTable;
GO

CREATE TABLE dbo.DataTable(
    ID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED, 
    TextCol CHAR(8000) NOT NULL
)
GO 

DECLARE @counter INT
SET @counter = 0 

WHILE @counter < 450   
BEGIN 
    INSERT INTO dbo.DataTable (TextCol)
    SELECT 'Sample Text.'
    SET @counter = @counter + 1
END 
GO 

INSERT INTO dbo.DataTable(TextCol)
SELECT a.TextCol
FROM dbo.DataTable a
CROSS JOIN dbo.DataTable b

SELECT COUNT(*) AS RecordsInTable
FROM dbo.DataTable;
GO 

/* Copy this code to another window and run when the delete finishes. */
/* 
USE DemoADR;
GO
CHECKPOINT;
GO
SHUTDOWN WITH NOWAIT;
GO
*/

/* Start the delete. */
USE DemoADR;
GO
BEGIN TRAN
DELETE from dbo.DataTable
GO

/* Copy this code to another window and run when the delete finishes. */
/* 
USE DemoADR;
GO
CHECKPOINT;
GO
SHUTDOWN WITH NOWAIT;
GO
*/

/* Examine the startup messages in the log for DemoADR. 
   Depending on how long it takes the DB to recover, you 
   may need to wait, or run this a few times to get all the 
   recovery messages. 
*/
EXEC xp_readerrorlog 0,1,N'DemoADR';
GO

/* Did all of our rows make it back? */
SELECT COUNT(*) FROM DemoADR.dbo.DataTable; 
GO 

/* Now switch to [master] and turn ADR ON. */
USE [master]; 
GO

ALTER DATABASE [DemoADR] 
SET ACCELERATED_DATABASE_RECOVERY = ON ;
GO 

/* Copy this code to another window and run when the delete finishes. */
/* 
USE DemoADR;
GO
CHECKPOINT;
GO
SHUTDOWN WITH NOWAIT;
GO
*/

/* Start the delete again, and kill it from the second window. */
USE DemoADR;
GO
BEGIN TRAN
DELETE from dbo.DataTable
GO

/* Now examine the ADR message after the server starts. */
SELECT name, is_accelerated_database_recovery_on
FROM sys.databases
WHERE name = 'DemoADR';

EXEC xp_readerrorlog 0,1,N'DemoADR';
GO


