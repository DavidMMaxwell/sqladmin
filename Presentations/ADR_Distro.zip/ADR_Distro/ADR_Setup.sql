/***************************************************************
  Name: Setup and Manage ADR
  Author: David M Maxwell (david.maxwell@microsoft.com)
  Last Updated: Apr 32 2020
  Notes: This script sets up the demo database and shows some 
  basic info re: Accelerated Database Recovery. 

  The demo database takes up 20GB on disk due to the 
  required size of the transaction log and PVS. Ensure sufficient 
  space is available before running these demos. This is so that 
  any latency or other performance issues are *not* a result of 
  transaction log growth. 
  
  Remember to update the file paths shown below to appropriate
  ones for your system.

  Based on code by Bob Ward. Download full workshop from: 
  https://github.com/microsoft/sqlworkshops-sql2019workshop


***************************************************************/
SET NOCOUNT ON;
USE [master];
GO

/* Create Demo Database */ 
DROP DATABASE IF EXISTS DemoADR; 
GO 

CREATE DATABASE DemoADR
ON PRIMARY 
    (NAME = N'DemoADR_PRIMARY', FILENAME = 'C:\SQL\DEV2019\Data\DemoADR_PRIMARY.mdf', SIZE = 1GB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
LOG ON 
    (NAME = N'DemoADR_LOG', FILENAME = 'C:\SQL\DEV2019\Logs\DemoADR_LOG.ldf', SIZE = 15GB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
GO

USE [DemoADR];
GO

IF EXISTS (SELECT [object_id] FROM sys.sql_modules WHERE [object_id] = object_id('dbo.GetIntegerStringFromHex'))
BEGIN 
    DROP FUNCTION [dbo].[GetIntegerStringFromHex]
END
GO 

/* Add this function so we can examine the tlog later. */
CREATE FUNCTION [dbo].[GetIntegerStringFromHex] (
  @lsn nvarchar(22) = N'000000a4:000000d8:0001',
  @IncludeColons BIT = 1
  )
/*
Converts LSN to three part decimal so you can pass it to fn_dblog() as a parameter.
By: Louis T Garrett  
*/
RETURNS NVARCHAR(22)
AS
begin
RETURN
(select
-- If the '0x' marker is NOT present:
RIGHT(replicate('0',8) + CAST(CONVERT(INT, CONVERT(VARBINARY, left(@lsn,8), 2)) AS NVARCHAR(8)),8)
+ CASE WHEN @IncludeColons = 1 THEN ':' ELSE '' END + RIGHT(replicate('0',8) + CAST(CONVERT(INT, CONVERT(VARBINARY, substring(@lsn,10,8), 2)) AS NVARCHAR(8)),8)
+ CASE WHEN @IncludeColons = 1 THEN ':' ELSE '' END + right(replicate('0',4) + CAST(CONVERT(INT, CONVERT(VARBINARY, right(@lsn,4), 2)) AS NVARCHAR(4)),4)
)
END
GO

/* Ensure the database is in the FULL recovery model to observe log records and used size. */
ALTER DATABASE DemoADR
SET RECOVERY SIMPLE;
GO 

/* "Backup" to get the recovery model set. */
BACKUP DATABASE DemoADR
TO DISK = N'C:\SQL\DEV2019\Backups\DemoADR.bak'
WITH INIT, COMPRESSION, CHECKSUM; 
GO 

/* Show that ADR is *off* by default. */
SELECT name, is_accelerated_database_recovery_on 
FROM sys.databases
WHERE name = N'DemoADR'; 
GO 

/* Recommendation is that PVS gets its own filegroup. */
USE [master]; 
GO 

ALTER DATABASE DemoADR
ADD FILEGROUP DemoADR_FG_PVS;
GO 

ALTER DATABASE DemoADR
ADD FILE (
    NAME = DemoADR_PVS,
    FILENAME = 'C:\SQL\DEV2019\Data\DemoADR_PVS.ndf',
    SIZE = 5GB, 
    FILEGROWTH = 1GB
) 
TO FILEGROUP DemoADR_FG_PVS; 
GO 

/* Turn ADR on in the new filegroup. */
ALTER DATABASE [DemoADR] 
SET ACCELERATED_DATABASE_RECOVERY = ON (
    PERSISTENT_VERSION_STORE_FILEGROUP = DemoADR_FG_PVS
);
GO 


/* Examine PVS Status */
USE DemoADR; 
GO 

SELECT 
    DBName = db.name, 
    ADR_State = CASE db.is_accelerated_database_recovery_on WHEN 1 THEN 'Enabled' ELSE 'Disabled' END,
    FGName = fg.name, 
    PVS_Size_MB = pvss.persistent_version_store_size_kb / 1024, 
    Online_Index_VS_MB = pvss.online_index_version_store_size_kb / 1024,
    Secondary_Low_Watermark = pvss.secondary_low_water_mark
FROM sys.dm_tran_persistent_version_store_stats pvss 
INNER JOIN master.sys.databases db 
    on pvss.database_id = db.database_id 
INNER JOIN sys.filegroups fg 
    ON fg.data_space_id = pvss.pvs_filegroup_id
WHERE pvss.database_id = db_id();
GO 


/* Error message reference for ADR. */
SELECT Error, Severity, Description 
FROM sys.sysmessages
WHERE msglangid = 1033 /* English */
  AND (description LIKE '%persistent version store%' OR Description LIKE '%Accelerated Database Recovery%')
ORDER BY Severity, Error
  ;
GO

/* Extended Events available for ADR. */
SELECT EventName = xp.name + '.' + xo.name, xo.Description 
FROM sys.dm_xe_objects xo 
INNER JOIN sys.dm_xe_packages xp
    ON xo.package_guid = xp.guid 
WHERE xo.name IN (
    'in_row_version_flag_cleared',
    'in_row_version_flag_set',
    'pvs_add_record',
    'pvs_cache_allocated',
    'pvs_cache_deallocated',
    'pvs_get_record',
    'pvs_page_deallocated',
    'pvs_trace',
    'ref_counted_pvs_page_allocation',
    'tx_version_optimized_insert_stats'
);
GO 

